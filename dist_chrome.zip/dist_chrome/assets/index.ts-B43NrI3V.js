import{s as e,A as r}from"./extensionState-D4tg8AFi.js";chrome.runtime.onInstalled.addListener(()=>{chrome.runtime.lastError||(chrome.storage.local.set(e),chrome.runtime.onMessage.addListener((t,a,o)=>{t.type===r.GET_STATE&&o(e),t.type===r.SET_STATE&&(Object.assign(e,t.payload),chrome.storage.local.set(e))}))});
//# sourceMappingURL=index.ts-B43NrI3V.js.map
